#!/bin/bash
# Azure App Service Linux Startup Script for Velo Backend
echo "Starting Velo FastAPI Backend on Azure App Service..."

# Run database migrations if alembic is present
if [ -f "backend/alembic.ini" ]; then
    echo "Running database migrations..."
    cd backend && alembic upgrade head && cd .. || true
fi

# Ensure uploads directories exist in persistent storage
mkdir -p uploads/evidence
mkdir -p uploads/reports

PORT="${PORT:-8000}"
WORKERS="${WEB_CONCURRENCY:-2}"

echo "Starting Gunicorn with ${WORKERS} Uvicorn workers on port ${PORT}..."
exec gunicorn \
    --bind "0.0.0.0:${PORT}" \
    --workers "${WORKERS}" \
    --worker-class uvicorn.workers.UvicornWorker \
    --timeout 120 \
    --access-logfile - \
    --error-logfile - \
    backend.app.main:app
